# Family Money Manager — Android
Native Android project for personal money management.

Features:
- Person types: Family, Friend, Relative, Other
- Purposes: Ghar, Loan, Study, Medical, Travel, Shopping, Other
- Name, amount, date, note
- Automatic totals and person-wise totals
- Payment history and delete
- Offline local storage

Open this folder in Android Studio and build the APK.
