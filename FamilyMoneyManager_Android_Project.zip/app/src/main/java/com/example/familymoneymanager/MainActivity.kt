package com.example.familymoneymanager

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Payment(val id:Long,val name:String,val type:String,val amount:Double,val purpose:String,val date:String,val note:String)

class MainActivity: Activity() {
    private lateinit var root: LinearLayout
    private val prefs by lazy { getSharedPreferences("data",0) }
    private val payments= mutableListOf<Payment>()
    private val types=arrayOf("Family","Friend","Relative","Other")
    private val purposes=arrayOf("Ghar","Loan","Study","Medical","Travel","Shopping","Other")
    override fun onCreate(b:Bundle?){super.onCreate(b);load();showDashboard()}
    private fun tv(s:String,size:Float=16f):TextView=TextView(this).apply{ text=s; textSize=size; setTextColor(Color.DKGRAY); setPadding(12,12,12,12)}
    private fun btn(s:String, action:()->Unit)=Button(this).apply{text=s;setOnClickListener{action()}}
    private fun base(title:String):LinearLayout{ root=LinearLayout(this);root.orientation=LinearLayout.VERTICAL;root.setPadding(14,14,14,14);root.addView(tv("🏠 $title",22f)); return root }
    private fun nav(){ val n=LinearLayout(this);n.orientation=LinearLayout.HORIZONTAL;n.addView(btn("Dashboard"){showDashboard()},LinearLayout.LayoutParams(0,55,1f));n.addView(btn("+ Payment"){showAdd()},LinearLayout.LayoutParams(0,55,1f));n.addView(btn("History"){showHistory()},LinearLayout.LayoutParams(0,55,1f));root.addView(n)}
    private fun showDashboard(){
        base("Family Money Manager"); nav()
        val total=payments.sumOf{it.amount}; val loan=payments.filter{it.purpose=="Loan"}.sumOf{it.amount}; val study=payments.filter{it.purpose=="Study"}.sumOf{it.amount}
        root.addView(tv("Total payments: ₹${fmt(total)}",19f));root.addView(tv("Loan: ₹${fmt(loan)}   |   Study: ₹${fmt(study)}",17f))
        root.addView(tv("Person-wise total",19f))
        val names=payments.groupBy{it.name}.toSortedMap()
        if(names.isEmpty())root.addView(tv("Abhi koi payment nahi hai. + Payment se add karein."))
        names.forEach{(n,ps)->root.addView(tv("$n — ₹${fmt(ps.sumOf{it.amount})} (${ps.size} payments)"))}
        setContentView(root)
    }
    private fun showAdd(){
        base("Payment Add Karein");nav()
        val name=EditText(this);name.hint="Naam (Ammi / Rahul / Chacha...)";root.addView(name)
        val type=Spinner(this);type.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,types);root.addView(type)
        val amount=EditText(this);amount.hint="Amount ₹";amount.inputType=2;root.addView(amount)
        val pur=Spinner(this);pur.adapter=ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,purposes);root.addView(pur)
        val note=EditText(this);note.hint="Note";root.addView(note)
        val date=EditText(this);date.setText(SimpleDateFormat("dd-MM-yyyy",Locale.getDefault()).format(Date()));root.addView(date)
        root.addView(btn("SAVE PAYMENT"){
            val a=amount.text.toString().toDoubleOrNull()
            if(name.text.isNullOrBlank()||a==null||a<=0){Toast.makeText(this,"Naam aur valid amount bhariye",Toast.LENGTH_SHORT).show();return@btn}
            payments.add(Payment(System.currentTimeMillis(),name.text.toString().trim(),type.selectedItem.toString(),a,pur.selectedItem.toString(),date.text.toString(),note.text.toString()))
            save();Toast.makeText(this,"Payment saved",Toast.LENGTH_SHORT).show();showDashboard()
        })
        setContentView(root)
    }
    private fun showHistory(){
        base("Payment History");nav()
        if(payments.isEmpty())root.addView(tv("No payments yet.")) else payments.sortedByDescending{it.id}.forEach{p->
            val t=tv("${p.name}  •  ${p.type}\n₹${fmt(p.amount)}  •  ${p.purpose}\n${p.date}${if(p.note.isNotBlank())"  •  ${p.note}" else ""}")
            root.addView(t);root.addView(btn("Delete"){payments.removeAll{it.id==p.id};save();showHistory()})
        };setContentView(root)
    }
    private fun fmt(x:Double)=String.format(Locale.US,"%,.2f",x)
    private fun save(){val a=JSONArray();payments.forEach{p->a.put(JSONObject().apply{put("id",p.id);put("name",p.name);put("type",p.type);put("amount",p.amount);put("purpose",p.purpose);put("date",p.date);put("note",p.note)})};prefs.edit().putString("payments",a.toString()).apply()}
    private fun load(){try{val a=JSONArray(prefs.getString("payments","[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);payments.add(Payment(o.getLong("id"),o.getString("name"),o.getString("type"),o.getDouble("amount"),o.getString("purpose"),o.getString("date"),o.getString("note")))}}catch(_:Exception){}}
}